<?php echo "<!-- footer -->\n"; ?>
<div class="container">
    <hr>
    <footer>
        <p class="muted">
            <small><?php echo xlt('Onsite Patient Portal'); ?> Rel v5.0.2 Copyright &copy; <?php echo date('Y'); ?> By
                sjpadgett@gmail.com
            </small>
        </p>
    </footer>
</div>
</body>
</html>
