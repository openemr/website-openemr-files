Third Party: rii-mango
======================

JPEGLosslessDecoderJS
---------------------
* Web: https://github.com/rii-mango/JPEGLosslessDecoderJS
* Version: [2.0.2](https://github.com/rii-mango/JPEGLosslessDecoderJS/releases/tag/v2.0.2)
* Date: 19/03/2017
* Download: see release
* License: MIT (see https://github.com/rii-mango/JPEGLosslessDecoderJS/blob/v2.0.2/LICENSE)
* Description: JPEG Lossless decoder.
* Purpose for dwv: Decode JPEG embeded in DICOM.
