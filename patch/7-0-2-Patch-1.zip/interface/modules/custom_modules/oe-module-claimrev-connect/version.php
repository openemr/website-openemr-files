<?php

/*
 * package   OpenEMR
 * link           https://open-emr.org
 * author      Sherwin Gaddis <sherwingaddis@gmail.com>
 * Copyright (c) 2024.  Sherwin Gaddis <sherwingaddis@gmail.com>
 */

$v_major = '1';
$v_minor = '0';
$v_patch = '0';
$v_tag   = '';
$v_database = 0;
