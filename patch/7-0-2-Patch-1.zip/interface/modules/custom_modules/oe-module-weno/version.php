<?php

/**
 * Module Weno EZ Integration versioning file.
 * This file is used by the Modules installer for various reasons
 * but not fully implemented ($v_tag & $v_database).
 * Module SQL version will be set in the database by MM on Install and Upgrades.
 * */

$v_major = '1';
$v_minor = '0';
$v_patch = '0';
$v_tag   = '';
$v_database = 0;
