
1. Copy the oe-modify-patient-menu-example directory into interface/modules/custom_modules
2. Modify the custom_patient_menu.json file to suit your needs
3. Install the module using module installer Modules > Manage Modules
