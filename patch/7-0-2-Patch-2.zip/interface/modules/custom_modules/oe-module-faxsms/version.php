<?php

/**
 * Module FaxSMS SQL versioning flat file.
 * This file is used by the Modules installer for various reasons
 * but not fully implemented.
 * */

$v_major = '4';
$v_minor = '1';
$v_patch = '0';
