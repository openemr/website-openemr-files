<?php
require_once("templates/contraception_products.php");
?>

<script type="text/javascript" src='<?php echo "$web_root/interface/forms/fee_sheet/contraception_products/js/view_model.js?v=$v_js_includes"; ?>'></script>
<link rel="stylesheet" href="<?php echo $web_root;?>/interface/forms/fee_sheet/contraception_products/css/contraception_products.css" type="text/css">
